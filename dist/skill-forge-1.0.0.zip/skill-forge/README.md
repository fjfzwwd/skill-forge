# skill-forge · v1.0.0

把 SKILL.md 里的确定性步骤编译成自包含脚本，让模型只做判断。**零第三方依赖**，Python 3.9+，Windows / macOS / Linux 均可跑。

1.0.0 是可上架的正式版：15 个内置 op、Agent 语义补丁、NOT_READY 护栏、实测接口、内置测试套件、上架自检与打包。

设计文档见 `PRD.md`，规则见 `references/`，变更记录见 `CHANGELOG.md`。

## 安装

把本目录放进技能目录即可（如 `~/.workbuddy/skills/skill-forge/`）。无需 pip install。

```bash
python scripts/forge.py --version
python scripts/forge.py doctor .      # 上架自检
python scripts/forge.py selftest . -v # 全量回归
```

## 两条路径

| 路径 | 适用 | 流程 |
|---|---|---|
| **A · 自动草案（推荐）** | 中文编号步骤 + 统计/收集/读取/阈值 | `propose → [fill] → approve --yes → compile → verify → watch` |
| **B · 手工 IR** | 任意复杂流程 | `scan → 手写 ir.json → compile --ir → verify → watch` |

两条路径都**必须人审**：A 用 `approve` 显式签发，B 由人直接写 IR。机器草案与 Agent 补丁都永远不能直接编译。

### 路径 A：自带示例，复制即用

```bash
cd scripts
D=../examples/notes-audit-auto

python forge.py propose "$D"                     # 1. 自动推断 IR 草案（不可编译）
#    打开 build/review-sheet.md 核对：来源行号、置信度、L3 建议、未映射行
python forge.py approve "$D" --yes --by wwd     # 2. 人审签发（不加 --yes 只打印，退出 1）
python forge.py compile "$D"                     # 3. 编译（含 NOT_READY 护栏）
python forge.py verify "$D" --update-baseline   # 4. 显式建立基线
python forge.py verify "$D" --format jsonl      # 5. 回归（可喂外部 eval）
python forge.py watch  "$D"                     # 6. 漂移检查
python forge.py measure "$D" --runs 5 --record  # 7. 采样输出形状，供护栏使用
```

生成脚本输出（两条路径实测**完全一致**）：

```
=== RESULT ===
STATUS=NEEDS_CLEANUP
MD_COUNT=4
TODO_HITS=4
WATCH_LIST=notes/a.md,notes/b.md,notes/c.md,notes/d.md
CONFIG={"owner": "wwd", "review_cycle": "weekly", "todo_threshold": 3}
OWNER=wwd
ISSUE_COUNT=0
=== META ===
STEPS=6
```

### 路径 B：手工 IR

```bash
cd scripts
D=../examples/notes-audit
python forge.py scan   "$D"
python forge.py plan   "$D"                    # 只给候选清单
python forge.py compile "$D" --ir "$D/ir.json"
python forge.py verify "$D" --update-baseline && python forge.py watch "$D"
```

## 命令

| 命令 | 作用 | 退出码 |
|---|---|---|
| `scan <dir>` | 静态扫描，写 `build/scan.json` / `scan.md` | 0 |
| `plan <dir>` | 生成空 IR 草案（兼容旧路径） | 0 |
| `propose <dir>` | 自动推断 IR 草案 + 人审清单 | 0 |
| `fill <dir> --patch p.json [--by 来源]` | 合并 Agent/人工补丁，仍为草案；非法补丁不写入 | 2 = 校验失败 |
| `approve <dir> [--yes] [--by 姓名]` | 人工签发；不加 `--yes` 只打印清单 | 1 = 未签发，0 = 已签发 |
| `compile <dir> [--ir path] [--force]` | 生成 runner / 精简文档 / 报告 / 锁文件 | 2 = 门禁或护栏失败 |
| `verify <dir> [--update-baseline] [--format jsonl] [--record]` | 跑生成脚本并比对基线 | 1 = 缺基线或回归失败 |
| `watch <dir>` | 检测源文档与产物漂移 | 1 = DRIFT，2 = 未编译 |
| `guard <dir> [--min-runs N]` | 查询流程形状是否稳定 | 1 = NOT_READY |
| `measure <dir> [--runs N] [--record]` | 实测耗时 / 输出字节 / 形状稳定性 | 1 = 有失败运行 |
| `rollback <dir> --yes` | 从**原始**备份恢复源 SKILL.md | — |
| `batch <root> [选项]` | 批量扫描技能库（默认只读） | 0 |
| `ci <root> [--strict] [--format jsonl]` | CI 门禁：聚合 watch + verify | 1 = 门禁失败 |
| `doctor [root]` | 上架前自检 | 1 = 有问题 |
| `package [root] [--out dir]` | 打包可上传 zip + MANIFEST + UPLOAD | 1 = 回读校验失败 |
| `selftest [root] [-v]` | 内置 unittest 套件 | 1 = 有用例失败 |

默认 IR：`<dir>/build/ir.json`；默认草案：`<dir>/build/ir.proposed.json`。

## 人审闸门（硬规则）

`propose` 生成的 IR 带 `review_status: "PROPOSED"`，每个 step 带 `proposal` 元数据（置信度 + 推断依据 + 原文）。`IR.validate` **双重拦截**：顶层状态 + 每条残留元数据。`fill` 合并补丁后仍是 `PROPOSED`。唯一解锁方式是 `forge approve <dir> --yes --by <姓名>`，它剥离元数据、写 `approved_by` / `approved_at`，产出 `build/ir.json`。

```
compile → ERROR IR 仍是机器草案（review_status=PROPOSED）
          ERROR steps[n] 仍带 proposal 元数据   → 退出码 2
approve --yes → APPROVED by wwd → build/ir.json
compile → OK
```

## IR v1.1：15 个内置 op

| 分组 | op |
|---|---|
| 计数统计 | `count_files` `count_matches` `count_lines` `collect` |
| 读取解析 | `read_json` `read_text` `parse_csv` `json_get` `regex_extract` `pluck` |
| 校验 | `hash_files` `file_exists` |
| 决策 | `decide`（最多 1 个，`emit` 必须为 `status`） |
| 特权（默认关闭） | `shell`（`allow_shell`）、`run_script`（`allow_run_script`） |

`run_script` 只允许技能目录内的 `.py`、用当前 Python 解释器执行、`shell=False`、默认 30 秒超时、stdout 截断 64 KiB；需要 `allow_run_script=true` 且 IR 有 `approved_by`。**它可执行任意 Python，属 L3 风险**，`propose` 不会自动放通，只写进 `proposal.suggestions`；确需使用请按 `references/agent-authoring.md` 用 `forge fill` 显式补写。

编译门禁在生成前校验：溯源行号、op/args 白名单、参数类型与范围、正则合法性、变量声明顺序、保留键冲突、特权开关、源摘要、草案状态。完整字段见 `references/ir-schema.md`，空白模板见 `templates/ir.template.json`。

## Agent 补写语义步骤

```bash
cd scripts
cp ../templates/agent-patch.json "$D/my-patch.json"
# 编辑 source / args.path / allow_run_script
python forge.py fill "$D" --patch "$D/my-patch.json" --by opus
python forge.py approve "$D" --yes --by wwd
```

补丁只接受白名单键，合并后立刻跑完整 IR 校验；不合法就不写入。补丁原文存 `build/agent-patch.applied.json`，人审清单标 `confidence=agent`。

## NOT_READY 护栏与实测

`compile` 前会检查：最近 5 次运行的输出键集合是否一致、git 近 7 天源文档提交是否超过 4 次。判为 `NOT_READY` 就拒绝编译，`--force` 会写 `build/guard-override.json` 留痕（源一改即失效）。新技能无样本时为 `UNSAMPLED`，放行但给出 GUARD 提示。

`measure` 实测墙钟时间、输出字节、形状一致性；**不测**真实 tokenizer token 与模型步骤遵循率（那需要带模型的外部 eval runner）。`report.md` 的 token 数字始终是 12 token/行的粗估并显式标注。详见 `references/stability-and-measurement.md`。

## 批量与 CI

```bash
cd scripts
python forge.py batch ~/.workbuddy/skills --out ../reports --name skill-library
python forge.py batch .. --frequency freq.json --min-code 3
python forge.py ci . --strict --format jsonl
```

- 默认**只读**；`--propose` / `--compile-approved` 才写目标 `build/`，需显式开启。批量编译会显式建立基线。
- `ci` 从不写技能目录、从不自动建基线；缺基线直接判 FAIL。`--strict` 额外拦截「有草案无人审」。
- 模板：`templates/ci/github-actions.yml`、`templates/ci/gitlab-ci.yml`、`templates/ci/pre-commit.sh`。详见 `references/ci-integration.md`。

## 上架：自检与打包

```bash
cd scripts
python forge.py doctor .        # frontmatter / 版本 / 语法 / 引用 / 泄漏
python forge.py package .       # dist/skill-forge-1.0.0.zip + MANIFEST.json + UPLOAD.md
```

`doctor` 检查版本一致性、所有 `.py` 语法与 `.json` 合法性、文档内本地引用、发行文件里是否混入本机绝对路径或疑似密钥。`package` 排除 `build/` 与 `reports/`（示例产物由命令现场生成），zip 内带 `MANIFEST.json`（逐文件 sha256），回读做 CRC + 哈希双重校验。`dist/UPLOAD.md` 含可直接粘贴的 description、标签与安装后自检命令。

## 编译产物（都在 `build/`，不覆盖源文件）

| 文件 | 说明 |
|---|---|
| `ir.proposed.json` | 机器草案，`PROPOSED`，不可编译 |
| `review-sheet.md` | 人审清单：来源、置信度、L3 建议、未映射行、警告 |
| `agent-patch.applied.json` | `fill` 使用的补丁原文（如有） |
| `ir.json` | `approve --yes` 签发的正式 IR |
| `scripts/crystallized.py` | 自包含 runner，标准库，可独立分发 |
| `SKILL.md` | 精简版，**始终带可安装 frontmatter**，人审后再替换源文档 |
| `report.md` | 步骤清单、收益估算（非实测）、人审清单 |
| `ir.final.json` | 绑定源 sha256 的最终 IR |
| `crystallize.lock.json` | 源摘要 + 4 个产物哈希 + 签发人 |
| `fixtures/baseline.json` | 回归基线（只由 `--update-baseline` 创建） |
| `fixtures/runs.jsonl` | 输出形状采样（只由 `--record` 写入） |
| `measurement.json` / `.md` | `measure` 实测报告 |
| `guard-override.json` | `--force` 豁免留痕 |
| `backup/SKILL.md` | **首次编译前**的原始文档，重复编译不会覆盖 |

## 最小 IR

```json
{
  "version": "1",
  "target": "my-skill",
  "source_sha256": "auto",
  "review_status": "APPROVED",
  "approved_by": "human",
  "allow_shell": false,
  "allow_run_script": false,
  "prohibitions": ["只读，不修改文件"],
  "kept_for_model": ["根据结果撰写结论"],
  "steps": [
    {"id": "s1", "source": "SKILL.md:L12", "owner": "code",
     "op": "count_files", "args": {"glob": "notes/**/*.md"}, "emit": "n"},
    {"id": "s2", "source": "SKILL.md:L15", "owner": "code",
     "op": "decide", "args": {"rules": [{"when": "n > 3", "status": "WARN"}], "else": "OK"},
     "emit": "status"},
    {"id": "s3", "source": "SKILL.md:L18", "owner": "model", "note": "撰写结论"}
  ]
}
```

## 与 eval 生态对接

`verify --format jsonl` 与 `ci --format jsonl` 每行一个 case，可喂给 Anthropic skill-creator `evals/evals.json`、`skills-evals` 基线快照、阿里 Skill-Up `evals/eval.yaml`。本工具不重复实现 eval runner。

## 目录

```
skill-forge/
├── SKILL.md                  # 可安装技能定义
├── README.md / PRD.md / CHANGELOG.md / LICENSE
├── scripts/                  # CLI、编译器、护栏、批量、CI、探针、发布（标准库）
├── references/               # 归属判定 / IR / Agent 补丁 / 稳定性 / 输出 / 安全 / CI
├── templates/                # IR 模板、Agent 补丁模板、CI 三件套
├── evals/                    # 触发与行为评测用例
├── tests/                    # 内置 unittest 套件
├── examples/                 # 路径 A / B 端到端示例源文件
└── dist/                     # package 生成的发行包（不入库）
```

## FAQ

**为什么 propose 不能全自动？** 让模型凭理解改写流程会引入原文没有的要求。IR 强制溯源 + 显式签发，是这个产品的安全边界，也是与论文原型最大的差异。

**为什么产物不直接替换 SKILL.md？** 编译是可逆实验。人审清单确认后再替换，`rollback --yes` 一键恢复；重复编译不会覆盖原始备份。

**能执行任意命令吗？** 默认不能。内置 op 只读、无网络；`shell` 需 `allow_shell: true`（L2），`run_script` 需 `allow_run_script: true`（L3），两者都要人审签发，且都用 `shell=False` + 超时 + cwd 限定。

**改了源 SKILL.md 会怎样？** `watch` 返回 DRIFT，`ci` 判 FAIL，`compile` 也会被漂移护栏拒绝。必须重新 propose → 人审 → compile，或 `--force` 留痕豁免。

**第一次 verify 为什么失败？** 因为没有基线，而工具不会把一次未知好坏的运行当成期望值。先跑 `verify --update-baseline`。

**批量会污染技能库吗？** 默认只读；`--propose` / `--compile-approved` 才写目标 `build/`，且都需显式开启。

## 限制（诚实口径）

- `propose` 是启发式填表助手，不是语义编译器。真实技能库里大量候选是文档示例命令、知识描述或框架特有语法，自动固化的风险高于收益；未映射行与 L3 建议会逐条列出，由人决定补写或放弃。
- `run_script` 能执行技能目录内任意 Python，无法防住脚本自身的联网或写文件。只在脚本可信时开启。
- token 与步骤遵循率的**真实收益**未做带模型基准测试；`report.md` 只给估算，`measure` 只测脚本侧指标。
- 启发式扫描会误判，必须逐条人审。
