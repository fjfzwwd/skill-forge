# Changelog

## 1.0.0 — 2026-11-10

第一个可上架的正式版。目标是「装上去就能用、上传前能自检、出错能拦住」。

**新增**

- IR v1.1：15 个内置 op。新增 `run_script`、`read_text`、`parse_csv`、`count_lines`、
  `file_exists`、`regex_extract`、`pluck`，覆盖真实技能里最常见的「调用自带脚本 /
  解析外部格式」动作。
- `run_script` 是显式 L3 逃生口：只允许技能目录内的 `.py`、无 shell、有超时、
  需要 `allow_run_script=true` 且 IR 必须有 `approved_by` 签发人。propose 不会自动放通，
  只把候选写入 `proposal.suggestions`，由人用 `forge fill` 显式补。
- `forge fill`：Agent 或人提供 JSON 补丁，合并进草案并做完整 IR 校验；结果仍是
  `PROPOSED`，不绕过人审闸门。补丁原文存 `build/agent-patch.applied.json`。
- `forge guard` / compile 内置 NOT_READY 护栏：依据最近 N 次运行的输出键形状与
  git 近 7 天源文档改动次数判断流程是否稳定；不稳定直接拒绝编译，`--force` 留痕豁免。
- `forge measure`：实测墙钟时间、输出字节、输出形状一致性，报告明确标注不含真实
  tokenizer token 与模型遵循率。
- `forge doctor`：上架前自检（frontmatter / 版本一致 / .py 语法 / .json 合法 /
  文档引用 / 绝对路径与密钥泄漏 / __pycache__）。
- `forge package`：产出带 `MANIFEST.json`（逐文件 sha256）的 zip、回读 CRC 校验、
  `UPLOAD.md` 上架说明；包内不含 `build/` 与 `reports/`。
- `forge selftest`：内置 unittest 套件，覆盖 IR 门禁、路径穿越、新 op、回归、漂移、
  护栏、批量、CI、打包与 CLI。
- 生成的精简版 `SKILL.md` 始终带完整可安装 frontmatter（name / description /
  license / metadata.version / risk），不再照抄冗长的旧 description。
- `LICENSE`、`references/agent-authoring.md`、`references/stability-and-measurement.md`、
  `templates/agent-patch.json`、`tests/`。

**修复（均为会影响正确性的真 BUG）**

- `verify` 在缺基线时曾静默创建基线并返回 PASS；现在只有显式 `--update-baseline`
  才写基线，否则返回 `NO_BASELINE` + 退出 1。CI 与 `batch --compile-approved` 已适配。
- 编译期路径校验漏掉 Windows 盘符与 UNC 绝对路径；现统一由 `ir.bad_path` 拦截，
  运行时仍有 `relative_to(ROOT)` 二次防护。
- 重复编译曾覆盖 `build/backup/SKILL.md`，会毁掉唯一的原始文档副本；现只在首次创建。
- 源文档变更后（IR 写 `source_sha256: auto`）可直接重新编译，绕过漂移语义；
  现由 `_drift_guard` 拦截，`--force` 才允许并写 `override-audit.json`。
- 无 frontmatter 的 SKILL.md 被正文中的 `---` 水平线误判为 frontmatter，导致后续
  内容整段被吞；analyzer 与 proposer 统一改为「只有首行 `---` 才开启」。
- 子进程未指定编码，Windows 非 UTF-8 代码页下中文输出会崩；现全部强制 UTF-8 +
  `errors=replace`，runner 也 `reconfigure` stdout/stderr。
- 子进程超时未捕获会让 `verify` 抛栈；现返回 FAIL。
- 生成 runner 的 `--root` 缺参数会 IndexError；现返回结构化 `STATUS=ERROR`。
- 非法正则 / 错误参数类型 / 未定义变量 / 与协议保留键冲突的 emit 过去要到运行期才炸，
  现全部在编译门禁拦截。
- `decide.when` 的右值、状态标识符合法性在编译期校验。
- 版本号散落在 5 处字符串（0.1.0 / 0.2.0 混用）；现统一 `scripts/version.py`，
  `doctor` 会检查代码与文档一致。

**口径**

- 覆盖率探针与批量报告都是启发式统计，不是实测收益；报告内显式标注。
- `run_script` 可执行技能目录内任意 Python，风险等级 L3，默认关闭。

## 0.2.0 — 2026-11-10

M1：`propose` / `approve` 人审闸门、批量扫描 `batch`、CI 门禁 `ci`、
`core.py` 复用层、真实技能库只读报告。

## 0.1.0 — 2026-11-09

M0：`scan` / `plan` / `compile` / `verify` / `watch` / `rollback`、
Crystallize IR v1（8 个 op）、自包含 runner、精简 SKILL.md、报告、锁文件、回归基线。
