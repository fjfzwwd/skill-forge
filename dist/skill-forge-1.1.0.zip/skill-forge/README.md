# skill-forge · v1.1.0

把 SKILL.md 里的确定性步骤编译成自包含脚本，让模型只做判断。**零第三方依赖**，Python 3.9+，Windows / macOS / Linux 均可跑。

1.1.0 在 1.0.0 的 15 个内置 op、Agent 语义补丁、NOT_READY 护栏、实测接口、内置测试、上架自检与打包之上，补齐了**权限签发链路、真实端到端示例、实测报告与一键干净目录验收**。

设计文档见 `PRD.md`，规则见 `references/`，变更记录见 `CHANGELOG.md`。

## 安装

把本目录放进技能目录即可（如 `~/.workbuddy/skills/skill-forge/`）。无需 pip install。

```bash
python scripts/forge.py --version
python scripts/forge.py doctor .         # 上架自检
python scripts/forge.py selftest . -v    # 45 条内置回归
python scripts/forge.py smoke .          # 干净目录 23 步端到端验收（推荐）
```

`smoke` 会把发行包解压到全新临时目录、从零跑完所有示例与 CI 门禁，是判断「这份拷贝是否真的能独立运行」最快的方式。

## 三条路径

| 路径 | 适用 | 流程 |
|---|---|---|
| **A · 自动草案** | 中文编号步骤 + 统计/收集/读取/阈值 | `propose → [fill] → approve --yes → compile → verify → watch` |
| **B · 手工 IR** | 任意复杂流程 | `scan → 手写 ir.json → compile --ir → verify → watch` |
| **C · 真实技能（推荐学习）** | 有 CSV、自带脚本、L3 动作 | `propose → fill → approve --enable-run-script → compile → verify → measure → report → watch` |

三条路径都**必须人审**：A/C 用 `approve` 显式签发，B 由人直接写 IR。机器草案与 Agent 补丁永远不能直接编译；L2/L3 权限只能在 `approve` 阶段由人显式放通。

### 路径 C：`examples/data-audit/`

最完整的示例，含带 BOM 的 CSV、JSON 清单、变更记录、技能自带的 `examples/data-audit/scripts/validate.py` 与 `examples/data-audit/agent-patch.json`。

```bash
cd scripts
D=../examples/data-audit

python forge.py propose "$D"
python forge.py fill "$D" --patch "$D/agent-patch.json" --by opus
#   打开 build/review-sheet.md 逐条核对，特别是 run_script 那一步
python forge.py approve "$D" --yes --by wwd --enable-run-script   # 唯一可放通 L3 的地方
python forge.py compile "$D"
python forge.py verify "$D" --update-baseline
python forge.py measure "$D" --runs 3            # 自动生成 report.measured.md
python forge.py watch "$D"
```

12 个 code 步骤覆盖 13 个内置 op，输出 `STATUS=BLOCK`、`METRIC_NAMES=latency_ms,...`、`RELEASES=2026.11.10,...`、`VALIDATION_OK=true`。`shell` 刻意不演示：它是 L2 风险，正常流程没有正当用途。

### 路径 A / B

```bash
cd scripts
A=../examples/notes-audit-auto
python forge.py propose "$A" && python forge.py approve "$A" --yes --by wwd
python forge.py compile "$A" && python forge.py verify "$A" --update-baseline
python forge.py verify "$A" --format jsonl && python forge.py watch "$A"

B=../examples/notes-audit
python forge.py compile "$B" --ir "$B/ir.json"
python forge.py verify "$B" --update-baseline && python forge.py watch "$B"
```

A/B 两条路径产出的结构化结果**完全一致**：`STATUS=NEEDS_CLEANUP`、`MD_COUNT=4`、`TODO_HITS=4` 等 7 个键。

## 命令

| 命令 | 作用 | 退出码 |
|---|---|---|
| `scan <dir>` | 静态扫描，写 `build/scan.json` / `scan.md` | 0 |
| `plan <dir>` | 生成空 IR 草案（兼容旧路径） | 0 |
| `propose <dir>` | 自动推断 IR 草案 + 人审清单 | 0 |
| `fill <dir> --patch p.json [--by 来源]` | 合并 Agent/人工补丁，仍为草案；非法或提权补丁不写入 | 2 = 校验/策略失败 |
| `approve <dir> [--yes] [--by 姓名] [--enable-shell] [--enable-run-script]` | 人工签发并（仅在此处）放通 L2/L3 | 1 = 未签发，2 = 策略拒绝 |
| `compile <dir> [--ir path] [--force]` | 生成 runner / 精简文档 / 报告 / 锁文件 | 2 = 门禁或护栏失败 |
| `verify <dir> [--update-baseline] [--format jsonl] [--record]` | 跑生成脚本并比对基线 | 1 = 缺基线或回归失败 |
| `watch <dir>` | 检测源文档与产物漂移；提示 guard 豁免状态 | 1 = DRIFT，2 = 未编译 |
| `guard <dir> [--min-runs N]` | 查询流程形状是否稳定 | 1 = NOT_READY |
| `measure <dir> [--runs N] [--record]` | 实测耗时 / 输出字节 / 形状稳定性，并刷新实测报告 | 1 = 有失败运行 |
| `report <dir> [--measurement path]` | 把实测数据合并进不进锁的 `report.measured.md` | 2 = 缺编译产物或实测数据 |
| `smoke [root] [--no-zip] [--timeout N]` | 干净目录一键端到端验收 | 1 = 有步骤失败 |
| `rollback <dir> --yes` | 从**原始**备份恢复源 SKILL.md | — |
| `batch <root> [选项]` | 批量扫描技能库（默认只读） | 0 |
| `ci <root> [--strict] [--format jsonl]` | CI 门禁：聚合 watch + verify | 1 = 门禁失败 |
| `doctor [root]` | 上架前自检 | 1 = 有问题 |
| `package [root] [--out dir]` | 打包可上传 zip + MANIFEST + UPLOAD | 1 = 回读校验失败 |
| `selftest [root] [-v]` | 内置 unittest 套件（45 条） | 1 = 有用例失败 |

默认 IR：`<dir>/build/ir.json`；默认草案：`<dir>/build/ir.proposed.json`。

## 人审闸门与权限收口（硬规则）

`propose` 生成的 IR 带 `review_status: "PROPOSED"`，每个 step 带 `proposal` 元数据（置信度 + 推断依据 + 原文）。`IR.validate` **双重拦截**：顶层状态 + 每条残留元数据。`fill` 合并补丁后仍是 `PROPOSED`。唯一解锁方式是 `forge approve <dir> --yes --by <姓名>`。

**L2/L3 只认一个入口**：`approve` 签发时无条件把 `allow_shell` / `allow_run_script` 重置为 `false`，只有 `--enable-shell` / `--enable-run-script` 能放通，并写 `elevated_by` / `elevated_at`；`IR.validate` 要求 `elevated_by == approved_by`。Agent 补丁、机器草案、手工改 JSON 都无法自我提权。IR 里没有对应特权步骤时，放通请求会被拒绝（避免无谓提权）。

```
fill patch {"allow_run_script": true}  → ERROR 补丁不得自我提权，退出 2
approve --yes（无 flag，IR 含 run_script）→ ERROR 需 --enable-run-script，退出 2
approve --yes --enable-run-script      → APPROVED + elevated_by=审阅者
compile                                → OK
```

## IR v1.1：15 个内置 op

| 分组 | op |
|---|---|
| 计数统计 | `count_files` `count_matches` `count_lines` `collect` |
| 读取解析 | `read_json` `read_text` `parse_csv` `json_get` `regex_extract` `pluck` |
| 校验 | `hash_files` `file_exists` |
| 决策 | `decide`（最多 1 个，`emit` 必须为 `status`） |
| 特权（默认关闭） | `shell`（`allow_shell`）、`run_script`（`allow_run_script`） |

`run_script` 只允许技能目录内的 `.py`、用当前 Python 解释器执行、`shell=False`、默认 30 秒超时、stdout 截断 64 KiB；需要 `allow_run_script=true` + `approved_by` + `elevated_by`。**它可执行任意 Python，属 L3 风险**，`propose` 不会自动放通，只写进 `proposal.suggestions`；确需使用按 `references/agent-authoring.md` 用 `fill` 补步骤、`approve --enable-run-script` 放通。

`read_text` / `parse_csv` 用 `utf-8-sig` 解码，兼容 Excel 导出的带 BOM CSV（否则首列名会带 `\ufeff`，`pluck` 静默取不到值）。

编译门禁在生成前校验：溯源行号、op/args 白名单、参数类型与范围、正则合法性、变量声明顺序、保留键冲突、特权开关与签发、源摘要、草案状态。完整字段见 `references/ir-schema.md`，空白模板见 `templates/ir.template.json`。

## Agent 补写语义步骤

```bash
cd scripts
cp ../templates/agent-patch.json "$D/my-patch.json"
# 编辑 source / args.path；不要写 allow_* 开关（会被拒绝）
python forge.py fill "$D" --patch "$D/my-patch.json" --by opus
python forge.py approve "$D" --yes --by wwd --enable-run-script
```

补丁只接受白名单键（`_` 前缀为注释，忽略），合并后立刻跑完整 IR 校验；不合法就不写入。补丁原文存 `build/agent-patch.applied.json`，人审清单标 `confidence=agent`。`steps_replace` 里不存在的 id 会给 WARN，`steps_add` 含特权步骤会提示签发时需要的 flag。完整示例见 `examples/data-audit/agent-patch.json`。

## NOT_READY 护栏与实测

`compile` 前会检查：最近 5 次运行的输出键集合是否一致、git 近 7 天源文档提交是否超过 4 次。判为 `NOT_READY` 就拒绝编译，`--force` 写 `build/guard-override.json` 留痕；豁免**绑定源 sha256 且 24 小时后自动失效**，源一改或过期即失效。新技能无样本时为 `UNSAMPLED`，放行但给出 GUARD 提示。

`measure` 实测墙钟时间、输出字节、形状一致性；**不测**真实 tokenizer token 与模型步骤遵循率（那需要带模型的外部 eval runner）。`report.md`（锁内）的 token 数字始终是 12 token/行的粗估并显式标注；`measure` 会自动把实测写到 `build/report.measured.md`（不进锁，`watch` 仍 CLEAN）。详见 `references/stability-and-measurement.md`。

## 批量、CI 与跨平台

```bash
cd scripts
python forge.py batch ~/.workbuddy/skills --out ../reports --name skill-library
python forge.py ci . --strict --format jsonl
python forge.py smoke .          # 完整验收；--no-zip 时用发行清单代替 dist zip
```

- 默认**只读**；`--propose` / `--compile-approved` 才写目标 `build/`，需显式开启。
- `ci` 从不写技能目录、从不自动建基线；缺基线直接判 FAIL。`--strict` 额外拦截「有草案无人审」。
- GitHub Actions 模板是 **3 OS × Python 3.9/3.13** 矩阵并跑 `smoke`；GitLab 是双版本并行；pre-commit 保持轻量只跑 `ci`。详见 `references/ci-integration.md`。
- 全项目源码已用 `ast.parse(feature_version=(3, 9))` 校验过语法兼容性。

## 上架：自检与打包

```bash
cd scripts
python forge.py doctor .        # frontmatter / 版本 / 语法 / 引用 / 泄漏
python forge.py package .       # dist/skill-forge-1.1.0.zip + MANIFEST.json + UPLOAD.md
python forge.py smoke .         # 用刚生成的 zip 做干净目录验收
```

`doctor` 检查版本一致性、所有 `.py` 语法与 `.json` 合法性、文档内本地引用（支持相对文档目录）、发行文件里是否混入本机绝对路径或疑似密钥。`package` 排除 `build/` 与 `reports/`，zip 内带 `MANIFEST.json`（逐文件 sha256），回读做 CRC + 哈希双重校验。`dist/UPLOAD.md` 含可直接粘贴的 description、标签与安装后自检命令。

## 编译产物（都在 `build/`，不覆盖源文件）

| 文件 | 说明 |
|---|---|
| `ir.proposed.json` | 机器草案，`PROPOSED`，不可编译 |
| `review-sheet.md` | 人审清单：来源、置信度、L3 建议、未映射行、警告 |
| `agent-patch.applied.json` | `fill` 使用的补丁原文（如有） |
| `ir.json` | `approve --yes` 签发的正式 IR（可能含 `elevated_by`） |
| `scripts/crystallized.py` | 自包含 runner，标准库，可独立分发 |
| `SKILL.md` | 精简版，**始终带可安装 frontmatter**，人审后再替换源文档 |
| `report.md` | 步骤清单、收益估算（非实测）、人审清单；**在漂移锁内** |
| `report.measured.md` | 估算 + 实测合并报告；**不进锁** |
| `ir.final.json` | 绑定源 sha256 的最终 IR |
| `crystallize.lock.json` | 源摘要 + 4 个产物哈希 + 签发人 |
| `fixtures/baseline.json` | 回归基线（只由 `--update-baseline` 创建） |
| `fixtures/runs.jsonl` | 输出形状采样（只由 `--record` 写入） |
| `measurement.json` / `.md` | `measure` 实测数据 |
| `guard-override.json` | `--force` 豁免留痕（含 `expires_at`，24h TTL） |
| `backup/SKILL.md` | **首次编译前**的原始文档，重复编译不会覆盖 |

## 最小 IR

```json
{
  "version": "1",
  "target": "my-skill",
  "source_sha256": "auto",
  "review_status": "APPROVED",
  "approved_by": "human",
  "allow_shell": false,
  "allow_run_script": false,
  "prohibitions": ["只读，不修改文件"],
  "kept_for_model": ["根据结果撰写结论"],
  "steps": [
    {"id": "s1", "source": "SKILL.md:L12", "owner": "code",
     "op": "count_files", "args": {"glob": "notes/**/*.md"}, "emit": "n"},
    {"id": "s2", "source": "SKILL.md:L15", "owner": "code",
     "op": "decide", "args": {"rules": [{"when": "n > 3", "status": "WARN"}], "else": "OK"},
     "emit": "status"},
    {"id": "s3", "source": "SKILL.md:L18", "owner": "model", "note": "撰写结论"}
  ]
}
```

`target` 用 `ir.slugify_target()` 规范化目录名；目录名含点/空格时会自动转成 `my_skill` 这类合法标识符。

## 与 eval 生态对接

`verify --format jsonl` 与 `ci --format jsonl` 每行一个 case，可喂给 Anthropic skill-creator `evals/evals.json`、`skills-evals` 基线快照、阿里 Skill-Up `evals/eval.yaml`。本工具不重复实现 eval runner。

## 目录

```
skill-forge/
├── SKILL.md                  # 可安装技能定义
├── README.md / PRD.md / CHANGELOG.md / LICENSE
├── scripts/                  # CLI、编译器、护栏、批量、CI、探针、smoke、发布（标准库）
├── references/               # 归属判定 / IR / Agent 补丁 / 稳定性 / 输出 / 安全 / CI
├── templates/                # IR 模板、Agent 补丁模板、CI 三件套
├── evals/                    # 触发与行为评测用例
├── tests/                    # 45 条内置 unittest
├── examples/
│   ├── notes-audit/          # 路径 B：手工 IR
│   ├── notes-audit-auto/     # 路径 A：自动草案
│   └── data-audit/           # 路径 C：CSV + 自带脚本 + L3 放通 + 实测
└── dist/                     # package 生成的发行包（不入库）
```

## FAQ

**为什么 propose 不能全自动？** 让模型凭理解改写流程会引入原文没有的要求。IR 强制溯源 + 显式签发，是这个产品的安全边界，也是与论文原型最大的差异。

**为什么 `fill` 不能开 `allow_run_script`？** 补丁是机器产物，让它决定权限等于让被审查对象自己签批。L3 只能由人在 `approve` 用显式参数放通，且要留名。

**为什么产物不直接替换 SKILL.md？** 编译是可逆实验。人审清单确认后再替换，`rollback --yes` 一键恢复；重复编译不会覆盖原始备份。

**能执行任意命令吗？** 默认不能。内置 op 只读、无网络；`shell` 需 `--enable-shell`（L2），`run_script` 需 `--enable-run-script`（L3），两者都要人审签发，且都用 `shell=False` + 超时 + cwd 限定。

**改了源 SKILL.md 会怎样？** `watch` 返回 DRIFT，`ci` 判 FAIL，`compile` 也会被漂移护栏拒绝。必须重新 propose → 人审 → compile，或 `--force` 留痕豁免（24h 有效）。

**第一次 verify 为什么失败？** 因为没有基线，而工具不会把一次未知好坏的运行当成期望值。先跑 `verify --update-baseline`。

**怎么确认这份压缩包真的能用？** `python scripts/forge.py smoke .`，它会解压 zip 到干净临时目录并跑完 23 步，含两条负例。

## 限制（诚实口径）

- `propose` 是启发式填表助手，不是语义编译器。真实技能库里大量候选是文档示例命令、知识描述或框架特有语法，自动固化的风险高于收益；未映射行与 L3 建议会逐条列出，由人决定补写或放弃。
- 低自动映射率是**安全策略的产物，不是 KPI**。新增 op 提供的是「人/Agent 有能力表达」的空间，不是「机器自动放通」的许可；正确路径是 `propose → fill → approve --enable-* → compile`。
- `run_script` 能执行技能目录内任意 Python，无法防住脚本自身的联网或写文件。只在脚本可信时开启。
- token 与步骤遵循率的**真实收益**未做带模型基准测试；`report.md` 只给估算，`measure` 只测脚本侧指标。
- 启发式扫描会误判，必须逐条人审。
- 跨平台矩阵模板已提供，但本地端到端验收只在 Windows / Python 3.13 跑过；Linux/macOS 行为由 CI 模板覆盖，未在本次实测。
